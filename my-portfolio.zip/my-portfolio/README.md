# My Portfolio Project (Bootcamp Tailwind CSS)

This is a simple, responsive personal portfolio website built using **Tailwind CSS (via CDN)**.  
The project was created as part of the **Bootcamp Project Guidelines**.

## ✅ Sections Included:
- **Home:** Introduction, Profile Photo, Role, Tagline, Resume Download
- **About:** Skills, Education, Experience
- **Projects:** 3 Sample Projects with Images & Descriptions
- **Contact:** Styled Form (Name, Email, Message)

## 🛠 Technologies Used:
- **HTML5**
- **Tailwind CSS (CDN)** — No build tools, no npm
- **Responsive Layouts:** Flexbox / Grid via Tailwind utilities
- **Clean, Modern Design**

## 📄 Folder Structure:
my-portfolio/
│
├── index.html
├── images/
│ ├── profile.jpg
│ ├── project1.jpg
│ ├── project2.jpg
│ └── project3.jpg
└── README.md


## 🎯 Key Features:
- Fully responsive on desktop, tablet, and mobile
- Clean and professional layout
- Hover effects on projects for engagement
- Smooth scroll between sections
- Tailwind utility-first classes only
- No JavaScript frameworks used

## 📂 How to Run:
1. Open `index.html` directly in any modern browser.
2. Or deploy via GitHub Pages / Netlify / Vercel.

---

### 👨‍💻 Author:
**Gawish Chugh**  
[LinkedIn] | [GitHub] | [Email]

